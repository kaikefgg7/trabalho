<link rel="stylesheet" type="text/css" href="comprafront.css">
<body>

	<div class="tabela-preco">

		
		<div class="card-preco">
			<h3 class="card-preco-header">MEIA FRONT</h3>
			<div class="preco"><sup>R$</sup>160<span>/Ingresso</span></div>
			<ul>
				<li>Limite de 3 ingressos</li>
				<li> Reserve para ter prioridade! </li>
				<li><strong>Escolha a quantidade: </strong></li>
                <select name="ingressos">
                 <option value="1">01</option>
                 <option value="2">02</option>
                 <option value="3">03</option>
                 </select>
               <li><strong>Clique em "Reservar" </strong></li>

			</ul>
			<a href="#" class="btn">Reservar</a>
			
		</div>
		<div class="card-preco">
			<h3 class="card-preco-header">INTEIRA FRONT</h3>
			<div class="preco"><sup>R$</sup>320<span>/Ingresso</span></div>
			<ul>
				<li>Limite de 3 ingressos</li>
				<li> Reserve para ter prioridade! </li>
				<li><strong>Escolha a quantidade: </strong></li>
                <select name="ingressos">
                 <option value="1">01</option>
                 <option value="2">02</option>
                 <option value="3">03</option>
                 </select>
               <li><strong>Clique em "Reservar" </strong></li>
			</ul>
			<a href="#" class="btn">Reservar</a>

            
			
</div>
</body>
</html>