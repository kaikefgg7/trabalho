<link rel="stylesheet" href="conteudo.css">
 <div class='texto' style="background-color: white; border-radius:15px; margin: 20px">
<br><p> <h1> Bem-vindo ao UnipeTickets! </h1> <br>

<h3> Descubra o portal definitivo para a experiência musical dos seus sonhos. No UnipeTickets, mergulhe em um universo de entretenimento incomparável, onde a emoção começa antes mesmo do primeiro acorde ser tocado. Somos apaixonados por proporcionar acesso facilitado aos melhores shows e eventos, garantindo que cada fã viva momentos memoráveis. </h3><br>

<br> <h2>Por que escolher o UnipeTickets? </h2> <br>

<br> <h3> Variedade Inigualável: Explore uma ampla gama de shows, desde ícones globais até as promessas mais quentes da cena musical. Nosso catálogo abrange todos os gêneros, garantindo que todos encontrem algo que os faça vibrar. <br> <br>

Compra Segura e Conveniente: Navegue em um ambiente seguro e user-friendly, projetado para tornar a compra de ingressos uma experiência simples e sem complicações. Nosso sistema de pagamento é seguro, protegendo suas informações em todas as transações. <br> <br>

Ingressos Garantidos: Elimine preocupações com ingressos falsos ou vendas não autorizadas. Trabalhamos diretamente com promotores e locais para garantir que cada ingresso adquirido seja autêntico e válido, proporcionando tranquilidade aos nossos clientes. <br> <br> 

Experiência Personalizada: Receba recomendações personalizadas com base em seus gostos musicais e histórico de compras. Queremos ajudá-lo a descobrir novos artistas e garantir que você esteja sempre atualizado sobre os eventos que realmente importam para você.<br> <br>


<br> No UnipeTickets, a jornada musical começa no momento em que você visita nosso site. Prepare-se para viver experiências únicas, compartilhar momentos inesquecíveis e celebrar sua paixão pela música. Reserve seus ingressos agora e faça parte do espetáculo! </h3> <br>


</div>



