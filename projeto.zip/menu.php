<link rel="stylesheet" href="menu.css">
<body style='background-color: #f0f0f0'>
    <nav class="fixed">
        <ul>
            <li>
                 <a href="index.php">Início  | </a>
                 <a href="?pg=principal">Shows  | </a>
                 <a href="?pg=entrar">Entrar  </a>

             </li>

        </ul> 

    </nav>
</body>