<link rel="stylesheet" href="principal.css">
<head>


</head>


<body>

<div class='images' style="background-color: white; border-radius:15px; margin: 20px">

  <div class="row">
    <img src="https://www.abrajetpb.com.br/wp-content/uploads/2023/11/WhatsApp-Image-2023-11-01-at-07.59.07-1017x1024.jpeg" alt="show">
    <div class='link'>
     <a href="http://localhost/progweb/compra.php">ARENA</a> <br>
    </div>
    <div class='link'>
     <a href="http://localhost/progweb/comprafront.php">FRONT </a>
    </div>
  </div>
  <div class="row">
    <img src="https://www.abrajetpb.com.br/wp-content/uploads/2023/11/WhatsApp-Image-2023-11-01-at-07.59.08-1024x1010.jpeg" alt="show">
    <div class='link'>
     <a href="http://localhost/progweb/compra.php">ARENA</a>
    </div>
    <div class='link'>
      <a href="http://localhost/progweb/comprafront.php">FRONT </a>
    </div>
    
  </div>
  <div class="row">
  <img src="https://www.abrajetpb.com.br/wp-content/uploads/2023/11/WhatsApp-Image-2023-11-01-at-07.59.08-1-1024x1022.jpeg" alt="show">
    <div class='link'>
     <a href="http://localhost/progweb/compra.php">ARENA</a>
    </div>
    <div class='link'>
     <a href="http://localhost/progweb/comprafront.php">FRONT</a>
    </div>
  </div>

</div>
</body>