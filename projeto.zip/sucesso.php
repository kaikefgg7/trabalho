<?php
 $nome = $_REQUEST['nome'];
 $email = $_REQUEST['cpf'];
 $assunto = $_REQUEST['email'];


 echo "<h3>Obrigado $nome, você foi cadastrado com sucesso!</h3>";

?>