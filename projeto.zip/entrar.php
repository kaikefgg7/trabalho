<link rel="stylesheet" href="entrar.css">
<div style="background-color: white; border-radius:15px; margin: 0 40% 0 40%; ">
<br><h1>Login</h1>
<h3>Cadastre-se no site: </h3>

<form action="?pg=sucesso" method="post">
  <input placeholder='Nome' type="text" name="nome"> <br>
  <input placeholder='E-mail' type="email" name="email"> <br>
  <input placeholder='CPF'type="text" name="cpf"> <br>
  <input type="submit" value="Enviar">

</form>
<br></div>
